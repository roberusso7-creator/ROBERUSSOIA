
import React, { useEffect, useMemo, useState } from "react";

const MONTHS = [
  "Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno",
  "Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"
];
const SPECIAL = ["Da Programmare","Parking","In attesa"];
const PERIOD_OPTIONS = [...MONTHS, ...SPECIAL];

const sampleData = [
  { id: 1, name: "Mario Rossi", intervento: "Cataratta", period: "Marzo", sede: "Milano", date: "2025-03-12", note: "Pre-op ok", pay: "Assicurazione" },
  { id: 2, name: "Lucia Bianchi", intervento: "Rinoplastica", period: "Aprile", sede: "Roma", date: "", note: "Allergie da verificare", pay: "Saldo" },
  { id: 3, name: "Carlo Verdi", intervento: "By-pass", period: "Da Programmare", sede: "Milano", date: "", note: "Anamnesi completa", pay: "" },
  { id: 4, name: "Anna Neri", intervento: "Protesi ginocchio", period: "Marzo", sede: "Torino", date: "2025-03-22", note: "Fisioterapia prevista", pay: "Convenzione" },
  { id: 5, name: "Paolo Gallo", intervento: "Endoscopia", period: "In attesa", sede: "Bologna", date: "", note: "Re-schedule", pay: "" },
  { id: 6, name: "Giulia Fontana", intervento: "Cataratta", period: "Maggio", sede: "Roma", date: "2025-05-02", note: "Ok", pay: "Pagamento effettuato" },
  { id: 7, name: "Marco De Santis", intervento: "Tonsillectomia", period: "Parking", sede: "Milano", date: "", note: "Valutare anestesia", pay: "" },
  { id: 8, name: "Elena Russo", intervento: "Chirurgia estetica", period: "Giugno", sede: "Napoli", date: "2025-06-10", note: "Foto pre-op", pay: "Parziale" },
  { id: 9, name: "Federico Sala", intervento: "Artroscopia", period: "Aprile", sede: "Torino", date: "2025-04-18", note: "", pay: "" },
  { id: 10, name: "Sofia Lotti", intervento: "Isteroscopia", period: "Marzo", sede: "Bologna", date: "2025-03-05", note: "", pay: "" },
];

const COLOR_MAP = {};
MONTHS.forEach((m,i)=>{
  const hue = Math.round((i / MONTHS.length) * 360);
  COLOR_MAP[m] = `hsl(${hue} 70% 96%)`;
});
COLOR_MAP["Da Programmare"] = "hsl(10 80% 90%)";
COLOR_MAP["Parking"] = "hsl(40 80% 94%)";
COLOR_MAP["In attesa"] = "hsl(60 90% 96%)";

export default function App(){
  const [patients, setPatients] = useState(() => {
    const raw = localStorage.getItem("robeia_patients_v1");
    return raw ? JSON.parse(raw) : sampleData;
  });
  const [search, setSearch] = useState("");
  const [filterSede, setFilterSede] = useState("");
  const [filterPeriod, setFilterPeriod] = useState("");
  const [showAdd, setShowAdd] = useState(false);

  useEffect(() => {
    localStorage.setItem("robeia_patients_v1", JSON.stringify(patients));
  }, [patients]);

  const sedes = useMemo(()=> {
    const s = new Set(patients.map(p=>p.sede).filter(Boolean));
    return Array.from(s);
  }, [patients]);

  const filtered = useMemo(()=> {
    return patients.filter(p=>{
      const q = search.trim().toLowerCase();
      if(q){
        const inName = p.name.toLowerCase().includes(q);
        const inInterv = p.intervento.toLowerCase().includes(q);
        if(!inName && !inInterv) return false;
      }
      if(filterSede && p.sede !== filterSede) return false;
      if(filterPeriod && p.period !== filterPeriod) return false;
      return true;
    });
  }, [patients, search, filterSede, filterPeriod]);

  const grouped = useMemo(()=>{
    const groups = {};
    [...MONTHS, ...SPECIAL].forEach(k=>groups[k]=[]);
    filtered.forEach(p=> {
      if(!groups[p.period]) groups[p.period]=[];
      groups[p.period].push(p);
    });
    return groups;
  }, [filtered]);

  function addPatient(obj){
    const id = Math.max(0, ...patients.map(p=>p.id)) + 1;
    setPatients(prev => [{ id, ...obj }, ...prev]);
    setShowAdd(false);
  }
  function updatePatient(id, patch){
    setPatients(prev => prev.map(p => p.id===id ? { ...p, ...patch } : p));
  }
  function deletePatient(id){
    if(!confirm("Eliminare il paziente?")) return;
    setPatients(prev => prev.filter(p => p.id !== id));
  }

  return (
    <div className="container">
      <div className="header">
        <div>
          <div className="h-title">Robe IA</div>
          <div className="h-sub">Gestione Pazienti — prototipo</div>
        </div>
        <div style={{display:'flex',gap:8}}>
          <button className="btn" onClick={()=>{ setPatients(sampleData); localStorage.removeItem('robeia_patients_v1'); }}>Reset dati</button>
          <button className="btn btn-primary" onClick={()=>setShowAdd(true)}>+ Aggiungi paziente</button>
        </div>
      </div>

      <div className="filters">
        <input className="input" placeholder="Cerca per nome o intervento" value={search} onChange={e=>setSearch(e.target.value)} />
        <select className="input" value={filterSede} onChange={e=>setFilterSede(e.target.value)}>
          <option value="">Tutte le sedi</option>
          {sedes.map(s => <option key={s} value={s}>{s}</option>)}
        </select>
        <select className="input" value={filterPeriod} onChange={e=>setFilterPeriod(e.target.value)}>
          <option value="">Tutti i periodi</option>
          {PERIOD_OPTIONS.map(p => <option key={p} value={p}>{p}</option>)}
        </select>
        <div style={{marginLeft:'auto'}} className="counter">{filtered.length} risultati</div>
      </div>

      <div>
        {Object.keys(grouped).map(period => {
          const items = grouped[period];
          if(!items || items.length===0) return null;
          return (
            <section key={period}>
              <div className="section-title">——— {period.toUpperCase()} ———</div>
              <div className="table-wrap" style={{marginTop:8}}>
                <table className="table">
                  <thead>
                    <tr>
                      <th>Nominativo</th>
                      <th>Intervento</th>
                      <th>Periodo</th>
                      <th>Sede</th>
                      <th>Data (opz.)</th>
                      <th>Note</th>
                      <th>Pay</th>
                      <th>Azioni</th>
                    </tr>
                  </thead>
                  <tbody>
                    {items.map(p => (
                      <tr key={p.id} style={{background: COLOR_MAP[p.period] || '#fff'}}>
                        <td>{p.name}</td>
                        <td>{p.intervento}</td>
                        <td>
                          <select value={p.period} onChange={e=>updatePatient(p.id, { period: e.target.value })}>
                            {PERIOD_OPTIONS.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                          </select>
                        </td>
                        <td><input value={p.sede} onChange={e=>updatePatient(p.id, { sede: e.target.value })} /></td>
                        <td><input type="date" value={p.date || ''} onChange={e=>updatePatient(p.id, { date: e.target.value })} /></td>
                        <td><input value={p.note || ''} onChange={e=>updatePatient(p.id, { note: e.target.value })} style={{width:220}} /></td>
                        <td><input value={p.pay || ''} onChange={e=>updatePatient(p.id, { pay: e.target.value })} style={{width:120}} /></td>
                        <td className="row-actions">
                          <button className="btn" onClick={()=>{ navigator.clipboard?.writeText(JSON.stringify(p)); alert('Dati paziente copiati'); }}>Copia</button>
                          <button className="btn" onClick={()=>deletePatient(p.id)}>Elimina</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          );
        })}
      </div>

      {showAdd && <AddModal onClose={()=>setShowAdd(false)} onAdd={addPatient} defaultSede={sedes[0] || ''} />}
    </div>
  );
}

function AddModal({ onClose, onAdd, defaultSede }){
  const [name, setName] = useState("");
  const [intervento, setIntervento] = useState("");
  const [period, setPeriod] = useState(MONTHS[0]);
  const [sede, setSede] = useState(defaultSede || "");
  const [date, setDate] = useState("");
  const [note, setNote] = useState("");
  const [pay, setPay] = useState("");

  function submit(){
    if(!name || !intervento){ alert('Inserisci Nominativo e Intervento'); return; }
    onAdd({ name, intervento, period, sede, date, note, pay });
  }

  return (
    <div className="modal-back">
      <div className="modal">
        <h3 style={{margin:0, marginBottom:8}}>Aggiungi paziente</h3>
        <div style={{display:'grid',gap:8}}>
          <input placeholder="Nominativo" value={name} onChange={e=>setName(e.target.value)} />
          <input placeholder="Intervento" value={intervento} onChange={e=>setIntervento(e.target.value)} />
          <select value={period} onChange={e=>setPeriod(e.target.value)}>
            {PERIOD_OPTIONS.map(p=> <option key={p} value={p}>{p}</option>)}
          </select>
          <input placeholder="Sede" value={sede} onChange={e=>setSede(e.target.value)} />
          <input type="date" value={date} onChange={e=>setDate(e.target.value)} />
          <input placeholder="Note" value={note} onChange={e=>setNote(e.target.value)} />
          <input placeholder="Pay" value={pay} onChange={e=>setPay(e.target.value)} />
        </div>
        <div style={{display:'flex',justifyContent:'flex-end',gap:8,marginTop:12}}>
          <button className="btn" onClick={onClose}>Annulla</button>
          <button className="btn btn-primary" onClick={submit}>Aggiungi</button>
        </div>
      </div>
    </div>
  );
}
